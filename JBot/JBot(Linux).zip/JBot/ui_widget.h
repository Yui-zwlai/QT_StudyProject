/********************************************************************************
** Form generated from reading UI file 'widget.ui'
**
** Created by: Qt User Interface Compiler version 4.8.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QComboBox>
#include <QtGui/QGridLayout>
#include <QtGui/QGroupBox>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QPushButton>
#include <QtGui/QSpacerItem>
#include <QtGui/QSpinBox>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Widget
{
public:
    QGridLayout *gridLayout_3;
    QGroupBox *groupBox;
    QGridLayout *gridLayout;
    QLabel *label;
    QComboBox *comboBox;
    QPushButton *pushButton_open;
    QLabel *label_2;
    QSpinBox *spinBox;
    QPushButton *pushButton_play;
    QPushButton *pushButton_auto;
    QPushButton *pushButton_recording;
    QPushButton *pushButton_2;
    QPushButton *pushButton_rosluanch;
    QSpacerItem *horizontalSpacer;
    QGroupBox *groupBox_2;
    QGridLayout *gridLayout_2;
    QPushButton *pushButton_move1;
    QPushButton *pushButton_move2;
    QPushButton *pushButton_move3;
    QPushButton *pushButton_move4;

    void setupUi(QWidget *Widget)
    {
        if (Widget->objectName().isEmpty())
            Widget->setObjectName(QString::fromUtf8("Widget"));
        Widget->resize(1920, 1080);
        gridLayout_3 = new QGridLayout(Widget);
        gridLayout_3->setSpacing(6);
        gridLayout_3->setContentsMargins(11, 11, 11, 11);
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        groupBox = new QGroupBox(Widget);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setMaximumSize(QSize(251, 149));
        gridLayout = new QGridLayout(groupBox);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        label = new QLabel(groupBox);
        label->setObjectName(QString::fromUtf8("label"));

        gridLayout->addWidget(label, 0, 0, 1, 1);

        comboBox = new QComboBox(groupBox);
        comboBox->setObjectName(QString::fromUtf8("comboBox"));

        gridLayout->addWidget(comboBox, 0, 1, 1, 2);

        pushButton_open = new QPushButton(groupBox);
        pushButton_open->setObjectName(QString::fromUtf8("pushButton_open"));

        gridLayout->addWidget(pushButton_open, 0, 3, 1, 2);

        label_2 = new QLabel(groupBox);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        gridLayout->addWidget(label_2, 1, 0, 1, 1);

        spinBox = new QSpinBox(groupBox);
        spinBox->setObjectName(QString::fromUtf8("spinBox"));
        spinBox->setMinimum(1);
        spinBox->setMaximum(1000);
        spinBox->setValue(20);

        gridLayout->addWidget(spinBox, 1, 1, 1, 2);

        pushButton_play = new QPushButton(groupBox);
        pushButton_play->setObjectName(QString::fromUtf8("pushButton_play"));

        gridLayout->addWidget(pushButton_play, 1, 3, 1, 2);

        pushButton_auto = new QPushButton(groupBox);
        pushButton_auto->setObjectName(QString::fromUtf8("pushButton_auto"));

        gridLayout->addWidget(pushButton_auto, 2, 4, 1, 1);

        pushButton_recording = new QPushButton(groupBox);
        pushButton_recording->setObjectName(QString::fromUtf8("pushButton_recording"));

        gridLayout->addWidget(pushButton_recording, 2, 0, 1, 1);

        pushButton_2 = new QPushButton(groupBox);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));

        gridLayout->addWidget(pushButton_2, 2, 2, 1, 1);


        gridLayout_3->addWidget(groupBox, 0, 0, 1, 1);

        pushButton_rosluanch = new QPushButton(Widget);
        pushButton_rosluanch->setObjectName(QString::fromUtf8("pushButton_rosluanch"));
        pushButton_rosluanch->setMaximumSize(QSize(80, 25));

        gridLayout_3->addWidget(pushButton_rosluanch, 0, 1, 1, 1);

        horizontalSpacer = new QSpacerItem(1556, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        gridLayout_3->addItem(horizontalSpacer, 0, 2, 1, 1);

        groupBox_2 = new QGroupBox(Widget);
        groupBox_2->setObjectName(QString::fromUtf8("groupBox_2"));
        gridLayout_2 = new QGridLayout(groupBox_2);
        gridLayout_2->setSpacing(6);
        gridLayout_2->setContentsMargins(11, 11, 11, 11);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        pushButton_move1 = new QPushButton(groupBox_2);
        pushButton_move1->setObjectName(QString::fromUtf8("pushButton_move1"));
        pushButton_move1->setMinimumSize(QSize(250, 150));
        QFont font;
        font.setPointSize(150);
        font.setBold(true);
        font.setWeight(75);
        pushButton_move1->setFont(font);
        pushButton_move1->setIconSize(QSize(100, 16));

        gridLayout_2->addWidget(pushButton_move1, 0, 0, 1, 1);

        pushButton_move2 = new QPushButton(groupBox_2);
        pushButton_move2->setObjectName(QString::fromUtf8("pushButton_move2"));
        pushButton_move2->setMinimumSize(QSize(250, 150));
        pushButton_move2->setFont(font);

        gridLayout_2->addWidget(pushButton_move2, 0, 1, 1, 1);

        pushButton_move3 = new QPushButton(groupBox_2);
        pushButton_move3->setObjectName(QString::fromUtf8("pushButton_move3"));
        pushButton_move3->setMinimumSize(QSize(0, 150));
        pushButton_move3->setFont(font);

        gridLayout_2->addWidget(pushButton_move3, 1, 0, 1, 1);

        pushButton_move4 = new QPushButton(groupBox_2);
        pushButton_move4->setObjectName(QString::fromUtf8("pushButton_move4"));
        pushButton_move4->setMinimumSize(QSize(0, 150));
        pushButton_move4->setFont(font);

        gridLayout_2->addWidget(pushButton_move4, 1, 1, 1, 1);


        gridLayout_3->addWidget(groupBox_2, 1, 0, 1, 3);


        retranslateUi(Widget);

        QMetaObject::connectSlotsByName(Widget);
    } // setupUi

    void retranslateUi(QWidget *Widget)
    {
        Widget->setWindowTitle(QApplication::translate("Widget", "Widget", 0, QApplication::UnicodeUTF8));
        groupBox->setTitle(QApplication::translate("Widget", "\346\234\272\346\242\260\346\211\213", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("Widget", "\344\270\262\345\217\243\357\274\232", 0, QApplication::UnicodeUTF8));
        pushButton_open->setText(QApplication::translate("Widget", "\346\211\223\345\274\200", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("Widget", "\345\270\247\346\225\260\357\274\232", 0, QApplication::UnicodeUTF8));
        pushButton_play->setText(QApplication::translate("Widget", "\346\222\255\346\224\276", 0, QApplication::UnicodeUTF8));
        pushButton_auto->setText(QApplication::translate("Widget", "\350\207\252\345\212\250", 0, QApplication::UnicodeUTF8));
        pushButton_recording->setText(QApplication::translate("Widget", "\345\275\225\345\210\266", 0, QApplication::UnicodeUTF8));
        pushButton_2->setText(QApplication::translate("Widget", "\345\270\247", 0, QApplication::UnicodeUTF8));
        pushButton_rosluanch->setText(QApplication::translate("Widget", "rosluanch", 0, QApplication::UnicodeUTF8));
        groupBox_2->setTitle(QApplication::translate("Widget", "\347\247\273\345\212\250", 0, QApplication::UnicodeUTF8));
        pushButton_move1->setText(QApplication::translate("Widget", "\351\227\250\345\217\243", 0, QApplication::UnicodeUTF8));
        pushButton_move2->setText(QApplication::translate("Widget", "\345\216\225\346\211\200", 0, QApplication::UnicodeUTF8));
        pushButton_move3->setText(QApplication::translate("Widget", "\347\224\265\346\242\257", 0, QApplication::UnicodeUTF8));
        pushButton_move4->setText(QApplication::translate("Widget", "\345\261\225\347\244\272\345\216\205", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class Widget: public Ui_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET_H
