#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QMessageBox>
#include <QFile>
#include <QTime>
#include <QTimer>
#include "serial.h"
#include <QMovie>
#include <QDebug>
#define cout qDebug() << "[" <<__FILE__ <<":"<<__LINE__ <<"]"

#include <QProcess>
#include <phonon>


namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = 0);

    void PlayAction(QString filename, QString mp3name = NULL,int velocity = 0x2F);

    ~Widget();

private slots:
    void on_pushButton_open_clicked();

    void on_pushButton_play_clicked();

    void on_pushButton_2_clicked();

    void readData();

    void on_pushButton_recording_clicked();

    void on_pushButton_auto_clicked();

    void TimerTimeOut();

    void on_pushButton_move1_clicked();

    void on_pushButton_move2_clicked();

    void on_pushButton_rosluanch_clicked();

    void on_pushButton_move3_clicked();

    void on_pushButton_move4_clicked();

private:
    Ui::Widget *ui;

    Serial *m_serial;
    QStringList m_serialList;

    QString m_filePath;

    QFile *m_saveFile;

    QList<int> intList;

    QTimer * m_timer;

    QProcess p;

    Phonon::VideoPlayer *music;

    void Sleep(int msec);
};

#endif // WIDGET_H
