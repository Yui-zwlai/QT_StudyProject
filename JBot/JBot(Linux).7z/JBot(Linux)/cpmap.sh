cp mymap.yaml ./robot_1/src/xrobot_2/maps/
cp mymap.pgm ./robot_1/src/xrobot_2/maps/
