sleep 10s
./JBot &
