# -*- coding: utf-8 -*-
"""
Created on Tue Nov 12 19:59:01 2019

@author: R&D.Admin
"""


from multiprocessing import Process, Value
import multiprocessing
import time
import serial
import binascii
import threading
from threading import Thread
import inspect
import ctypes
import csv
import codecs


#ser = serial.Serial('COM7',250000)
S_buffer = [0xff,0xff,0x00,0x05,0x03,0x1E,0x00,0x00,0x00]
Dynamixel_pos=[]
hand_data = "C:/Users/HOME/Desktop/20201127.txt"
file = open(hand_data)

#for line in file.readlines(): 
#    line=line.rstrip("\n")
#    Dynamixel_pos.append(int(line))
#    
#
#file.close()    
#print(len(Dynamixel_pos))
#print(Dynamixel_pos)


for line in file.readlines(): 
    see_data = []
    eachline = line.split()###按行读取文本文件，每行数据以列表形式返回
    for i in range(0,len(eachline)):
        see_data.append(int(eachline[i]));
    # Dynamixel_pos.append(eachline)
    Dynamixel_pos.append(see_data)
  #   Dynamixel_pos.append(int(line))
    

file.close() 
print(Dynamixel_pos)
print(len(Dynamixel_pos))
'''
def Dynamixel_Write(ID,POS):
    
    SUM = 0
    S_buffer[2] = ID
    S_buffer[6] = (POS & 0x00ff)
    S_buffer[7] = ((POS & 0xFF00)>>8)
    for i in range(2,len(S_buffer)-1):       
        SUM +=  S_buffer[i]
    
    SUM = ~SUM
    SUM = SUM & 0xFF
    S_buffer[len(S_buffer)-1] = SUM     
    ser.write(bytearray(S_buffer))

def Dynamixel_power_off(ID):
    SUM = 0
    CMD = [0xff,0xff,ID,0x04,0x03,0x18,0x00,0x00]
    for i in range(2,len(CMD)-1):       
        SUM +=  CMD[i]
    
    SUM = ~SUM
    SUM = SUM & 0xFF
    CMD[len(CMD)-1] = SUM     
    ser.write(bytearray(CMD))     



while(1):
    action = input("input:")
    if(action == "yes"):
        for i in range(0,len(Dynamixel_pos)):
            Dynamixel_Write(0,Dynamixel_pos[i])
            
            t10 = round(time.clock(),3)
            t11 = t10 + 0.030
            t11 = round(t11,3)
            while(1):
                t10 = round(time.clock(),3)
                if(t10>=t11):
                    break
    
    elif(action == "no"):
        count = 0
        Dynamixel_power_off(11) 
        Dynamixel_power_off(12)
        Dynamixel_power_off(13)
        Dynamixel_power_off(14)
        Dynamixel_power_off(15)
        Dynamixel_power_off(16)
        time.sleep(1)
        ser.close()
        break

    else:
        for i in range(int(action),len(Dynamixel_pos),6):
            Dynamixel_Write(11,Dynamixel_pos[i])
            Dynamixel_Write(12,Dynamixel_pos[i+1])
            Dynamixel_Write(13,Dynamixel_pos[i+2])
            Dynamixel_Write(14,Dynamixel_pos[i+3])
            Dynamixel_Write(15,Dynamixel_pos[i+4])
            Dynamixel_Write(16,Dynamixel_pos[i+5])
            
            
            t10 = round(time.clock(),3)
            t11 = t10 + 0.030
            t11 = round(t11,3)
            while(1):
                t10 = round(time.clock(),3)
                if(t10>=t11):
                    break
'''                
  
