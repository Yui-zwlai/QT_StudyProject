# -*- coding: utf-8 -*-
"""
Created on Mon Nov 11 08:33:05 2019

@author: R&D.Admin
"""

from multiprocessing import Process, Value
import multiprocessing
import time
import serial
import binascii
import threading
from threading import Thread
import inspect
import ctypes
import csv
import codecs


ser = serial.Serial('COM7',1000000)
S_buffer = [0xff,0xff,0x00,0x05,0x03,0x1E,0x00,0x00,0x00]
R_pos_buff = [0xff,0xff,0x00,0x04,0x02,0x24,0x02,0x00]
R_D_buff = []
Data_buff = []
count = 0
delay_time = 0.0015
Dynamixel_pos = []
flag = 0
Dynamixel_ID=[0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09,0x0A,0x0B,0x0C,0x0D,0x0E,0x0F,0x10]
hand_data = "D:/RD/ZHli/2019/Dynamixel_data/hand.txt"
hand_data_2 = "D:/RD/ZHli/2019/Dynamixel_data/hand.csv"



def Dynamixel_Write(ID,POS):
    
    SUM = 0
    S_buffer[2] = ID
    S_buffer[6] = (POS & 0x00ff)
    S_buffer[7] = ((POS & 0xFF00)>>8)
    for i in range(2,len(S_buffer)-1):       
        SUM +=  S_buffer[i]
    
    SUM = ~SUM
    SUM = SUM & 0xFF
    S_buffer[len(S_buffer)-1] = SUM     
    ser.write(bytearray(S_buffer))
#    print(S_buffer)


def Dynamixel_read_pos(ID):
    SUM = 0
    R_pos_buff[2] = ID
    for i in range(2,len(R_pos_buff)-1):
        
        SUM +=  R_pos_buff[i]
    
    SUM = ~SUM
    SUM = SUM & 0xFF
    R_pos_buff[len(R_pos_buff)-1] = SUM             
    ser.write(bytearray(R_pos_buff))    
#    print(R_pos_buff)
    
            

    
def Dynamixel_rec_pos():
    read_byte = 0
    count = 1
    global flag
    while(1):
        num = ser.inWaiting()
        if(num>0):     
            read_byte = ord(ser.read())
            R_D_buff.append(read_byte)
#            print(len(R_D_buff))
            
            '''
            if(status == 0):
                if(read_byte == 0xff):               
                    status = 1
                    R_D_buff.append(read_byte)
                else:
                    status = 0
                    R_D_buff.clear()
                read_byte = 0
#                print(0)
                
            elif(status == 1):
                if(read_byte == 0xff):
                    status = 2
                    R_D_buff.append(read_byte)
                else:
                    status = 0
                    R_D_buff.clear()
                read_byte = 0
#                print(1)
                
            elif(status == 2):
                if(read_byte == R_pos_buff[2]):#是否等于当前ID
                    status = 3
                    R_D_buff.append(read_byte)
                else:
                    status = 0
                    R_D_buff.clear()
                read_byte = 0
#                print(2)
                
            elif(status == 3):
                if(read_byte == 0x04):
                    status = 4
                    R_D_buff.append(read_byte)
                else:
                   status = 0
                   R_D_buff.clear()
                read_byte = 0
#                print(3)
                
            elif(status == 4):
                if(read_byte == 0x00):
                    status = 5
                    R_D_buff.append(read_byte)
                else:
                   status = 0
                   R_D_buff.clear()
                read_byte = 0
#                print(4)
                
            elif(status == 5):
                R_D_buff.append(read_byte) 
                read_byte = 0
#                print(len(R_D_buff))
                
                if(len(R_D_buff)==7):
                    status = 6
                    
            elif(status == 6):
                R_D_buff.append(read_byte) #read_Dynamixel_pos_L
                read_byte = 0    
                
                for i in range(2,len(R_D_buff)-1):                    
                    SUM+=(R_D_buff[i])
                SUM = ~SUM
                SUM = SUM & 0xff
                if(SUM == (R_D_buff[len(R_D_buff) - 1])):
                    Dynamixel_pos.append((R_D_buff[6]*256)+R_D_buff[5])
                    status = 0
                    R_D_buff.clear()
                    SUM = 0
                    wait_flag = 0
                    
#                    print(tx,ty,ty-tx)
#                    print(Dynamixel_pos)
                else:
                    status = 0
                    R_D_buff.clear()
            '''        
def Dynamixel_data():
    global flag
    while(1):        
        if(len(R_D_buff)>=8):
            print(R_D_buff)
            R_SUM = 0
            if((R_D_buff[0])==0xff):
                if((R_D_buff[1])==0xff):
                    if((R_D_buff[2])==R_pos_buff[2]):
                        if((R_D_buff[3])==0x04):
                            if((R_D_buff[4])==0x00):
                                
                                for i in range(2,6):
                                    R_SUM+=((R_D_buff[i]))
                                R_SUM = ~R_SUM
                                R_SUM = R_SUM & 0xFF      
                                if(R_SUM == ((R_D_buff[7]))):
                                    
                                    Dynamixel_pos.append(((R_D_buff[6])*256)+(R_D_buff[5]))
                                    del R_D_buff[0:8]
                                                  
            
def Dynamixel_power_off(ID):
    SUM = 0
    CMD = [0xff,0xff,ID,0x04,0x03,0x18,0x00,0x00]
    for i in range(2,len(CMD)-1):       
        SUM +=  CMD[i]
    
    SUM = ~SUM
    SUM = SUM & 0xFF
    CMD[len(CMD)-1] = SUM     
    ser.write(bytearray(CMD))                        
                    
# 开启线程  参数1：方法名(不要带括号)
 
p = threading.Thread(target=Dynamixel_rec_pos)            
p.start() 


def _async_raise(tid, exctype):
    """raises the exception, performs cleanup if needed"""
    tid = ctypes.c_long(tid)
    if not inspect.isclass(exctype):
        exctype = type(exctype)
    res = ctypes.pythonapi.PyThreadState_SetAsyncExc(tid, ctypes.py_object(exctype))
    if res == 0:
        raise ValueError("invalid thread id")
    elif res != 1:
        # """if it returns a number greater than one, you're in trouble,
        # and you should call it again with exc=NULL to revert the effect"""
        ctypes.pythonapi.PyThreadState_SetAsyncExc(tid, None)
        raise SystemError("PyThreadState_SetAsyncExc failed")

def text_save(filename, data):#filename为写入CSV文件的路径，data为要写入数据列表.
    file = open(filename,'a')
    for i in range(len(data)):
        s = str(data[i]).replace('[','').replace(']','')#去除[],这两行按数据不同，可以选择
        s = s.replace("'",'').replace(',','') +'\n'   #去除单引号，逗号，每行末尾追加换行符
        file.write(s)
    file.close()
    print("保存文件成功")


def data_write_csv(file_name, datas):#file_name为写入CSV文件的路径，datas为要写入数据列表
    file_csv = codecs.open(file_name,'w+','utf-8')#追加
    writer = csv.writer(file_csv, delimiter=' ', quotechar=' ', quoting=csv.QUOTE_MINIMAL)
    writer.writerow(datas)
    print("保存文件成功，处理结束")
 
    
    
    

def stop_thread(thread):
    _async_raise(thread.ident, SystemExit)

    
def thread_send(ID):
    s = threading.Thread(target=Dynamixel_read_pos, args=(ID,))            
    s.start() 
           
while(1):
    
    
    if(count==300):
        print("录制完成！")
        time.sleep(5)
        print(len(R_D_buff))        
        while(1):
            if(len(R_D_buff)>=8):
                
                R_SUM = 0
                if((R_D_buff[0])==0xff):
                    print(1)
                    if((R_D_buff[1])==0xff):
                        print(2)
                        if((R_D_buff[2])in(Dynamixel_ID)):
                            print(3)
                            if((R_D_buff[3])==0x04):
                                print(4)
                                if((R_D_buff[4])==0x00):
                                    print(5)
                                    for i in range(2,7):
                                        R_SUM+=((R_D_buff[i]))
                                    R_SUM = ~R_SUM
                                    R_SUM = R_SUM & 0xFF      
                                    
                                    if(R_SUM == ((R_D_buff[7]))):
                                        
                                        Dynamixel_pos.append(((R_D_buff[6])*256)+(R_D_buff[5]))
                                        print(len(Dynamixel_pos))
                                        del R_D_buff[0:8]


            else:
                break   
        print(len(Dynamixel_pos))
        text_save(hand_data,Dynamixel_pos)
        data_write_csv(hand_data_2,Dynamixel_pos)
#        print(Dynamixel_pos)                           
        time.sleep(2)
        
        while(1):
            action = input("input:")
            if(action == "yes"):
                for i in range(0,len(Dynamixel_pos)):
                    Dynamixel_Write(0,Dynamixel_pos[i])
                    
                    t10 = round(time.clock(),3)
                    t11 = t10 + 0.030
                    t11 = round(t11,3)
                    while(1):
                        t10 = round(time.clock(),3)
                        if(t10>=t11):
                            break
            
            elif(action == "no"):
                count = 0
                Dynamixel_power_off(11) 
                Dynamixel_power_off(12)
                Dynamixel_power_off(13)
                Dynamixel_power_off(14)
                Dynamixel_power_off(15)
                Dynamixel_power_off(16)
                stop_thread(p)
                time.sleep(1)
                ser.close()
                break
            elif(action == "single"):
                while(1):
                    Single_action = input("Single_action:")
                    if(Single_action == "exit"):
                        break
                    else:
                        if(int(Single_action)>=150):
                            Single_action = "149"
                        Dynamixel_Write(0,Dynamixel_pos[int(Single_action)])
            else:
                for i in range(int(action),len(Dynamixel_pos),6):
                    Dynamixel_Write(11,Dynamixel_pos[i])
                    Dynamixel_Write(12,Dynamixel_pos[i+1])
                    Dynamixel_Write(13,Dynamixel_pos[i+2])
                    Dynamixel_Write(14,Dynamixel_pos[i+3])
                    Dynamixel_Write(15,Dynamixel_pos[i+4])
                    Dynamixel_Write(16,Dynamixel_pos[i+5])
                    
                    
                    t10 = round(time.clock(),3)
                    t11 = t10 + 0.030
                    t11 = round(t11,3)
                    while(1):
                        t10 = round(time.clock(),3)
                        if(t10>=t11):
                            break
                        
        break                     
        '''
        while(1):
            if(len(R_D_buff)<8):
                break
        for i in range(0,len(Dynamixel_pos)):
            Dynamixel_Write(0,Dynamixel_pos[i])
            
            t10 = round(time.clock(),3)
            t11 = t10 + 0.030
            t11 = round(t11,3)
            while(1):
                t10 = round(time.clock(),3)
                if(t10>=t11):
                    break
        Dynamixel_power_off(0)
        
        count = 0
        
        break  
        '''    
        
    count+=1    
    '''
    Dynamixel_read_pos(0)#1
    t100 = time.clock()    
    t200 = t100+0.030    
    t1 = time.clock()
    t2 = t1+delay_time
    while(t1<t2):
        t1 = time.clock()
   
    Dynamixel_read_pos(0)#2
    t1 = time.clock()
    t2 = t1+delay_time
    while(t1<t2):
        t1 = time.clock()
   
    Dynamixel_read_pos(0)#3
    t1 = time.clock()
    t2 = t1+delay_time
    while(t1<t2):
        t1 = time.clock()
   
    Dynamixel_read_pos(0)#4
    t1 = time.clock()
    t2 = t1+delay_time
    while(t1<t2):
        t1 = time.clock()
   
    Dynamixel_read_pos(0) #5   
    t1 = time.clock()
    t2 = t1+delay_time
    while(t1<t2):
        t1 = time.clock()
   
    Dynamixel_read_pos(0)    #6   
    t1 = time.clock()
    t2 = t1+delay_time
    while(t1<t2):
        t1 = time.clock()
   
    Dynamixel_read_pos(0) #7 
    t1 = time.clock()
    t2 = t1+delay_time
    while(t1<t2):
        t1 = time.clock()
   
    Dynamixel_read_pos(0) #8 
    t1 = time.clock()
    t2 = t1+delay_time
    while(t1<t2):
        t1 = time.clock()
   
    Dynamixel_read_pos(0)  #9   
    t1 = time.clock()
    t2 = t1+delay_time
    while(t1<t2):
        t1 = time.clock()
   
    Dynamixel_read_pos(0)  #10
    t1 = time.clock()
    t2 = t1+delay_time
    while(t1<t2):
        t1 = time.clock()
    '''
    Dynamixel_read_pos(11) #11
    t100 = time.clock()    
    t200 = t100+0.030     
    t1 = time.clock()
    t2 = t1+delay_time
    while(t1<t2):
        t1 = time.clock()
   
    Dynamixel_read_pos(12) #12    
    t1 = time.clock()
    t2 = t1+delay_time
    while(t1<t2):
        t1 = time.clock()
   
    Dynamixel_read_pos(13) #13
    t1 = time.clock()
    t2 = t1+delay_time
    while(t1<t2):
        t1 = time.clock()
   
    Dynamixel_read_pos(14) #14   
    t1 = time.clock()
    t2 = t1+delay_time
    while(t1<t2):
        t1 = time.clock()
   
    Dynamixel_read_pos(15) #15  
    t1 = time.clock()
    t2 = t1+delay_time
    while(t1<t2):
        t1 = time.clock()
   
    Dynamixel_read_pos(16) #16     
#    print(t100,t200)      
    while(t100<t200):
        t100 = time.clock()
        
    '''
    time.sleep(0.001)
    count+=1
    Dynamixel_read_pos(0) 
    '''

    

'''
count = 0
for i in range(30):
    if(i>28):
        ser.close()
        break
    
#    t2 = t + 0.01
#    t2 = round(t2,3)    
    
    Dynamixel_read_pos(0)
   
    #t10 = round(time.clock(),3)
    status = 0
    SUM = 0

#    print(count)
    
     
    while(1):
            

        
        num = ser.inWaiting()
        
        if(num>0):
            
            read_byte = ord(ser.read())
            t = time.clock()
            R_D_buff.append(read_byte)
            te=time.clock()
            print(te-t)            

               
            if(status == 0):

                if(read_byte == 0xff):               
                     
                    status = 1
                    R_D_buff.append(read_byte)
                 
                else:
                    status = 0
                    R_D_buff.clear()
                read_byte = 0
#                print(0)
              
            elif(status == 1):
                if(read_byte == 0xff):
                    status = 2
                    R_D_buff.append(read_byte)
                else:
                    status = 0
                    R_D_buff.clear()
                read_byte = 0
#                print(1)
               
            elif(status == 2):
                if(read_byte == R_pos_buff[2]):#是否等于当前ID
                    status = 3
                    R_D_buff.append(read_byte)
                else:
                    status = 0
                    R_D_buff.clear()
                read_byte = 0
#                print(2)
                 
            elif(status == 3):
                if(read_byte == 0x04):
                    status = 4
                    R_D_buff.append(read_byte)
                else:
                   status = 0
                   R_D_buff.clear()
                read_byte = 0
#                print(3)
                
            elif(status == 4):
                if(read_byte == 0x00):
                    status = 5
                    R_D_buff.append(read_byte)
                else:
                   status = 0
                   R_D_buff.clear()
                read_byte = 0
#                print(4)
                
            elif(status == 5):
                R_D_buff.append(read_byte) 
                read_byte = 0
#                print(len(R_D_buff))
                
                if(len(R_D_buff)==7):
                    status = 6
                    
            elif(status == 6):
                R_D_buff.append(read_byte) #read_Dynamixel_pos_L
                read_byte = 0    
                
                for i in range(2,len(R_D_buff)-1):                    
                    SUM+=(R_D_buff[i])
                SUM = ~SUM
                SUM = SUM & 0xff
                if(SUM == (R_D_buff[len(R_D_buff) - 1])):
                    Dynamixel_pos.append((R_D_buff[6]*256)+R_D_buff[5])
                    status = 0
                    R_D_buff.clear()
                    SUM = 0
                    wait_flag = 0
                    #t = time.clock()

                    break
#                    print(tx,ty,ty-tx)
                    
                else:
                    status = 0
                    R_D_buff.clear()
            
              
    #t11 = round(time.clock(),3)
    #print(t10,t11,t11-t10)
    while(1):
        
        t2 = time.clock()
        if(t2-t>=0.01):
            break       
    '''             
    
    
    
    
    
    
    
    
    
    
    
    
    
    