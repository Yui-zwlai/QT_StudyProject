﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JBot
{
    public partial class Form1 : Form
    {
        string File_current_address = null;
        public Form1()
        {
            InitializeComponent();
            textBox1.Text = "0";
            textBox2.Text = "0";
            textBox3.Text = "0";
            textBox4.Text = "0";
            textBox5.Text = "0";
            textBox6.Text = "0";
            textBox7.Text = "0";
            textBox8.Text = "0";
            textBox9.Text = "0";
            textBox10.Text = "0";
            textBox11.Text = "0";
            textBox12.Text = "0";
            textBox13.Text = "0";
            textBox14.Text = "0";
            textBox15.Text = "0";
            textBox16.Text = "0";
            textBox17.Text = "0";
            
        }
        
        private void button1_Click(object sender, EventArgs e)
        {
            UInt32 ROW = 0, Column = 0; 
            int r_count = 0;
            string[]items;
            openFileDialog1.Title = "选择训练的TXT文件";
    //        openFileDialog1.InitialDirectory = @"c:\";
            openFileDialog1.Filter = "(文本)|*.txt;|All files(*.*)|*.*";
         //   openFileDialog1.FilterIndex = 0;

            openFileDialog1.RestoreDirectory = true;

            
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                string fileName = System.IO.Path.GetFullPath(openFileDialog1.FileName);
                File_current_address = fileName;
                StreamReader sr = new StreamReader(fileName);
                

                
                while (!sr.EndOfStream)
                {
                    
                    items = sr.ReadLine().Split('\t');
                    //
                    Column = (UInt32)items.Length;
                    ROW++;
                }
                sr.Close();
                textBox1.Text = "0";
                dataGridView1.ColumnCount = (int)Column;
                dataGridView1.RowCount = (int)ROW+1;
                for(Int32 i=1;i<= ROW;i++)
                {
                    dataGridView1.Rows[i-1].HeaderCell.Value = i.ToString();
                }
                for (Int32 i = 0; i < Column; i++)
                {
                    dataGridView1.Columns[i].HeaderCell.Value = i.ToString();
                }
                /*               for (UInt16 i = 0; i < Column; i++)
                               {
                                   dataGridView1.Rows[2].Cells[i].Value = "haha";
                               }*/
                //       dataGridView1.Rows[0].Cells[0].Value = "haha";
                StreamReader sr2 = new StreamReader(fileName);
                while (!sr2.EndOfStream)
                {
                    items = sr2.ReadLine().Split('\t');
                    for(UInt16 i = 0;i<items.Length;i++)
                    {
                        dataGridView1.Rows[r_count].Cells[i].Value = items[i];
                    }
                    r_count += 1;

                }
                textBox1.Text = "1";
                //  dataGridView1.Columns[1].HeaderCell.Value = "1";
                //将datatable绑定到datagridview上显示结果  
                //文件以Tab分开
                /*     string[] ColNmae = strLine.Split(' ');
                     for (int i = 0; i < ColNmae.Length; i++)
                     {
                         //dt.Columns.Add(ColNmae[i]);
                         dt.Columns.Add();
                         dt.Columns[i].ColumnName = ColNmae[i];
                     }
                     while (true)
                     {
                         strLine = sr.ReadLine();
                         if (string.IsNullOrEmpty(strLine) == true)
                         {
                             break;
                         }
                         else
                         {
                             DataRow dr = dt.NewRow();
                             string[] strList = strLine.Split('\t');

                             for (int i = 0; i < strList.Length; i++)
                             {
                                 dr[ColNmae[i]] = strList[i];
                             }
                             dt.Rows.Add(dr);
                         }
                     }*/
                sr2.Close();
           //     dataGridView1.DataSource = dt;
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if(File.Exists(File_current_address))
            {
                File.Delete(File_current_address);
                FileStream fs = new FileStream(File_current_address, FileMode.Create);
                StreamWriter sw = new StreamWriter(fs);
                //开始写入
                for(Int32 i=0;i< dataGridView1.RowCount - 1;i++)
                {
                    for(UInt16 j=0;j< dataGridView1.ColumnCount;j++)
                    {
                        sw.Write(dataGridView1.Rows[i].Cells[j].Value);
                        if(j< dataGridView1.ColumnCount - 1)
                        {
                            sw.Write("\t");
                        }
                    }
                    if(i< dataGridView1.RowCount - 1 - 1)
                    {
                        sw.Write("\n");
                    }
                }
                //清空缓冲区
                sw.Flush();
                //关闭流
                sw.Close();
                fs.Close();
                MessageBox.Show("保存成功");
            }


            
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if(e.RowIndex >= 0 && e.RowIndex< dataGridView1.RowCount - 1)
            {
                textBox1.Text = (dataGridView1.CurrentCell.RowIndex + 1).ToString();
                textBox2.Text = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
                textBox3.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
                textBox4.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
                textBox5.Text = dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();
                textBox6.Text = dataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString();
                textBox7.Text = dataGridView1.Rows[e.RowIndex].Cells[5].Value.ToString();
                textBox8.Text = dataGridView1.Rows[e.RowIndex].Cells[6].Value.ToString();
                textBox9.Text = dataGridView1.Rows[e.RowIndex].Cells[7].Value.ToString();
                textBox10.Text = dataGridView1.Rows[e.RowIndex].Cells[8].Value.ToString();
                textBox11.Text = dataGridView1.Rows[e.RowIndex].Cells[9].Value.ToString();
                textBox12.Text = dataGridView1.Rows[e.RowIndex].Cells[10].Value.ToString();
                textBox13.Text = dataGridView1.Rows[e.RowIndex].Cells[11].Value.ToString();
                textBox14.Text = dataGridView1.Rows[e.RowIndex].Cells[12].Value.ToString();
                textBox15.Text = dataGridView1.Rows[e.RowIndex].Cells[13].Value.ToString();
                textBox16.Text = dataGridView1.Rows[e.RowIndex].Cells[14].Value.ToString();
                textBox17.Text = dataGridView1.Rows[e.RowIndex].Cells[15].Value.ToString();
            }

        }




        private void textBox2_KeyUp(object sender, KeyEventArgs e)
        {
            if (File.Exists(File_current_address))
            {
                if(Convert.ToUInt16(textBox2.Text)>=4095)
                {
                    textBox2.Text = "4095";
                }
                if (Convert.ToUInt16(textBox2.Text) <= 0)
                {
                    textBox2.Text = "0";
                }
                UInt16 a = Convert.ToUInt16(textBox1.Text);
                dataGridView1.Rows[a - 1].Cells[0].Value = textBox2.Text;
            }

        }

        private void textBox3_KeyUp(object sender, KeyEventArgs e)
        {
            if (File.Exists(File_current_address))
            {
                if (Convert.ToUInt16(textBox3.Text) >= 4095)
                {
                    textBox3.Text = "4095";
                }
                if (Convert.ToUInt16(textBox3.Text) <= 0)
                {
                    textBox3.Text = "0";
                }
                UInt16 a = Convert.ToUInt16(textBox1.Text);
                dataGridView1.Rows[a - 1].Cells[1].Value = textBox3.Text;
            }
        }

        private void textBox4_KeyUp(object sender, KeyEventArgs e)
        {
            if (File.Exists(File_current_address))
            {
                if (Convert.ToUInt16(textBox4.Text) >= 4095)
                {
                    textBox4.Text = "4095";
                }
                if (Convert.ToUInt16(textBox4.Text) <= 0)
                {
                    textBox4.Text = "0";
                }
                UInt16 a = Convert.ToUInt16(textBox1.Text);
                dataGridView1.Rows[a - 1].Cells[2].Value = textBox4.Text;
            }
        }

        private void textBox5_KeyUp(object sender, KeyEventArgs e)
        {
            if (File.Exists(File_current_address))
            {

                if (Convert.ToUInt16(textBox5.Text) >= 4095)
                {
                    textBox5.Text = "4095";
                }
                if (Convert.ToUInt16(textBox5.Text) <= 0)
                {
                    textBox5.Text = "0";
                }
                UInt16 a = Convert.ToUInt16(textBox1.Text);
                dataGridView1.Rows[a - 1].Cells[3].Value = textBox5.Text;
            }
        }

        private void textBox6_KeyUp(object sender, KeyEventArgs e)
        {
            if (File.Exists(File_current_address))
            {
                if (Convert.ToUInt16(textBox6.Text) >= 4095)
                {
                    textBox6.Text = "4095";
                }
                if (Convert.ToUInt16(textBox6.Text) <= 0)
                {
                    textBox6.Text = "0";
                }
                UInt16 a = Convert.ToUInt16(textBox1.Text);
                dataGridView1.Rows[a - 1].Cells[4].Value = textBox6.Text;
            }
        }

        private void textBox7_KeyUp(object sender, KeyEventArgs e)
        {
            if (File.Exists(File_current_address))
            {
                if (Convert.ToUInt16(textBox7.Text) >= 4095)
                {
                    textBox7.Text = "4095";
                }
                if (Convert.ToUInt16(textBox7.Text) <= 0)
                {
                    textBox7.Text = "0";
                }
                UInt16 a = Convert.ToUInt16(textBox1.Text);
                dataGridView1.Rows[a - 1].Cells[5].Value = textBox7.Text;
            }
        }

        private void textBox8_KeyUp(object sender, KeyEventArgs e)
        {
            if (File.Exists(File_current_address))
            {
                if (Convert.ToUInt16(textBox8.Text) >= 4095)
                {
                    textBox8.Text = "4095";
                }
                if (Convert.ToUInt16(textBox8.Text) <= 0)
                {
                    textBox8.Text = "0";
                }
                UInt16 a = Convert.ToUInt16(textBox1.Text);
                dataGridView1.Rows[a - 1].Cells[6].Value = textBox8.Text;
            }
        }

        private void textBox9_KeyUp(object sender, KeyEventArgs e)
        {
            if (File.Exists(File_current_address))
            {
                if (Convert.ToUInt16(textBox9.Text) >= 4095)
                {
                    textBox9.Text = "4095";
                }
                if (Convert.ToUInt16(textBox9.Text) <= 0)
                {
                    textBox9.Text = "0";
                }
                UInt16 a = Convert.ToUInt16(textBox1.Text);
                dataGridView1.Rows[a - 1].Cells[7].Value = textBox9.Text;
            }
        }

        private void textBox10_KeyUp(object sender, KeyEventArgs e)
        {
            if (File.Exists(File_current_address))
            {
                if (Convert.ToUInt16(textBox10.Text) >= 4095)
                {
                    textBox10.Text = "4095";
                }
                if (Convert.ToUInt16(textBox10.Text) <= 0)
                {
                    textBox10.Text = "0";
                }
                UInt16 a = Convert.ToUInt16(textBox1.Text);
                dataGridView1.Rows[a - 1].Cells[8].Value = textBox10.Text;
            }
        }

        private void textBox11_KeyUp(object sender, KeyEventArgs e)
        {
            if (File.Exists(File_current_address))
            {
                if (Convert.ToUInt16(textBox11.Text) >= 4095)
                {
                    textBox11.Text = "4095";
                }
                if (Convert.ToUInt16(textBox11.Text) <= 0)
                {
                    textBox11.Text = "0";
                }
                UInt16 a = Convert.ToUInt16(textBox1.Text);
                dataGridView1.Rows[a - 1].Cells[9].Value = textBox11.Text;
            }
        }

        private void textBox12_KeyUp(object sender, KeyEventArgs e)
        {
            if (File.Exists(File_current_address))
            {
                if (Convert.ToUInt16(textBox12.Text) >= 4095)
                {
                    textBox12.Text = "4095";
                }
                if (Convert.ToUInt16(textBox12.Text) <= 0)
                {
                    textBox12.Text = "0";
                }
                UInt16 a = Convert.ToUInt16(textBox1.Text);
                dataGridView1.Rows[a - 1].Cells[10].Value = textBox12.Text;
            }
        }

        private void textBox13_KeyUp(object sender, KeyEventArgs e)
        {
            if (File.Exists(File_current_address))
            {
                if (Convert.ToUInt16(textBox13.Text) >= 4095)
                {
                    textBox13.Text = "4095";
                }
                if (Convert.ToUInt16(textBox13.Text) <= 0)
                {
                    textBox13.Text = "0";
                }
                UInt16 a = Convert.ToUInt16(textBox1.Text);
                dataGridView1.Rows[a - 1].Cells[11].Value = textBox13.Text;
            }
        }

        private void textBox14_KeyUp(object sender, KeyEventArgs e)
        {
            if (File.Exists(File_current_address))
            {
                if (Convert.ToUInt16(textBox14.Text) >= 4095)
                {
                    textBox14.Text = "4095";
                }
                if (Convert.ToUInt16(textBox14.Text) <= 0)
                {
                    textBox14.Text = "0";
                }
                UInt16 a = Convert.ToUInt16(textBox1.Text);
                dataGridView1.Rows[a - 1].Cells[12].Value = textBox14.Text;
            }
        }

        private void textBox15_KeyUp(object sender, KeyEventArgs e)
        {
            if (File.Exists(File_current_address))
            {
                if (Convert.ToUInt16(textBox15.Text) >= 4095)
                {
                    textBox15.Text = "4095";
                }
                if (Convert.ToUInt16(textBox15.Text) <= 0)
                {
                    textBox15.Text = "0";
                }
                UInt16 a = Convert.ToUInt16(textBox1.Text);
                dataGridView1.Rows[a - 1].Cells[13].Value = textBox15.Text;
            }
        }

        private void textBox16_KeyUp(object sender, KeyEventArgs e)
        {
            if (File.Exists(File_current_address))
            {
                if (Convert.ToUInt16(textBox16.Text) >= 4095)
                {
                    textBox16.Text = "4095";
                }
                if (Convert.ToUInt16(textBox16.Text) <= 0)
                {
                    textBox16.Text = "0";
                }
                UInt16 a = Convert.ToUInt16(textBox1.Text);
                dataGridView1.Rows[a - 1].Cells[14].Value = textBox16.Text;
            }
        }

        private void textBox17_KeyUp(object sender, KeyEventArgs e)
        {
            if (File.Exists(File_current_address))
            {
                if (Convert.ToUInt16(textBox17.Text) >= 4095)
                {
                    textBox17.Text = "4095";
                }
                if (Convert.ToUInt16(textBox17.Text) <= 0)
                {
                    textBox17.Text = "0";
                }
                UInt16 a = Convert.ToUInt16(textBox1.Text);
                dataGridView1.Rows[a - 1].Cells[15].Value = textBox17.Text;
            }
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar != '\b')//这是允许输入退格键
            {
                if ((e.KeyChar < '0') || (e.KeyChar > '9'))//这是允许输入0-9数字
                {
                    e.Handled = true;

                }
            }
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar != '\b')//这是允许输入退格键
            {
                if ((e.KeyChar < '0') || (e.KeyChar > '9'))//这是允许输入0-9数字
                {
                    e.Handled = true;

                }
            }
        }

        private void textBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar != '\b')//这是允许输入退格键
            {
                if ((e.KeyChar < '0') || (e.KeyChar > '9'))//这是允许输入0-9数字
                {
                    e.Handled = true;

                }
            }
        }

        private void textBox5_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar != '\b')//这是允许输入退格键
            {
                if ((e.KeyChar < '0') || (e.KeyChar > '9'))//这是允许输入0-9数字
                {
                    e.Handled = true;

                }
            }
        }

        private void textBox6_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar != '\b')//这是允许输入退格键
            {
                if ((e.KeyChar < '0') || (e.KeyChar > '9'))//这是允许输入0-9数字
                {
                    e.Handled = true;

                }
            }
        }

        private void textBox7_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar != '\b')//这是允许输入退格键
            {
                if ((e.KeyChar < '0') || (e.KeyChar > '9'))//这是允许输入0-9数字
                {
                    e.Handled = true;

                }
            }
        }

        private void textBox8_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar != '\b')//这是允许输入退格键
            {
                if ((e.KeyChar < '0') || (e.KeyChar > '9'))//这是允许输入0-9数字
                {
                    e.Handled = true;

                }
            }
        }

        private void textBox9_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar != '\b')//这是允许输入退格键
            {
                if ((e.KeyChar < '0') || (e.KeyChar > '9'))//这是允许输入0-9数字
                {
                    e.Handled = true;

                }
            }
        }

        private void textBox10_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar != '\b')//这是允许输入退格键
            {
                if ((e.KeyChar < '0') || (e.KeyChar > '9'))//这是允许输入0-9数字
                {
                    e.Handled = true;

                }
            }
        }

        private void textBox11_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar != '\b')//这是允许输入退格键
            {
                if ((e.KeyChar < '0') || (e.KeyChar > '9'))//这是允许输入0-9数字
                {
                    e.Handled = true;

                }
            }
        }

        private void textBox12_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar != '\b')//这是允许输入退格键
            {
                if ((e.KeyChar < '0') || (e.KeyChar > '9'))//这是允许输入0-9数字
                {
                    e.Handled = true;

                }
            }
        }

        private void textBox13_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar != '\b')//这是允许输入退格键
            {
                if ((e.KeyChar < '0') || (e.KeyChar > '9'))//这是允许输入0-9数字
                {
                    e.Handled = true;

                }
            }
        }

        private void textBox14_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar != '\b')//这是允许输入退格键
            {
                if ((e.KeyChar < '0') || (e.KeyChar > '9'))//这是允许输入0-9数字
                {
                    e.Handled = true;

                }
            }
        }

        private void textBox15_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar != '\b')//这是允许输入退格键
            {
                if ((e.KeyChar < '0') || (e.KeyChar > '9'))//这是允许输入0-9数字
                {
                    e.Handled = true;

                }
            }
        }

        private void textBox16_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar != '\b')//这是允许输入退格键
            {
                if ((e.KeyChar < '0') || (e.KeyChar > '9'))//这是允许输入0-9数字
                {
                    e.Handled = true;

                }
            }
        }

        private void textBox17_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar != '\b')//这是允许输入退格键
            {
                if ((e.KeyChar < '0') || (e.KeyChar > '9'))//这是允许输入0-9数字
                {
                    e.Handled = true;

                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                try
                {
                    serialPort1.Close();
                    button3.Text = "打开串口";
                }
                catch
                {
                    MessageBox.Show("串口关闭失败");
                    button3.Text = "关闭串口";
                }
            }
            else
            {
                try
                {
                    serialPort1.PortName = comboBox1.SelectedItem.ToString();
                    serialPort1.Open();
                    button3.Text = "关闭串口";
                }
                catch
                {
                    MessageBox.Show("串口已被占用");
                    button3.Text = "打开串口";
                }
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                try
                {
                    serialPort1.Close();
                    serialPort1.PortName = comboBox1.SelectedItem.ToString();
                    serialPort1.Open();
                    button3.Text = "关闭串口";
                }
                catch
                {
                    button3.Text = "打开串口";
                    MessageBox.Show("串口已被占用！！！");
                }

            }
            else
            {
                serialPort1.PortName = comboBox1.SelectedItem.ToString();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string[] PortName = SerialPort.GetPortNames();
            for (int i = 0; i < PortName.Length; i++)
            {
                comboBox1.Items.Add(PortName[i]);
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if(Convert.ToUInt16(textBox1.Text)>0 && Convert.ToUInt16(textBox1.Text)< dataGridView1.RowCount)
            {
                textBox2.Text = dataGridView1.Rows[Convert.ToUInt16(textBox1.Text)-1].Cells[0].Value.ToString();
                textBox3.Text = dataGridView1.Rows[Convert.ToUInt16(textBox1.Text) - 1].Cells[1].Value.ToString();
                textBox4.Text = dataGridView1.Rows[Convert.ToUInt16(textBox1.Text) - 1].Cells[2].Value.ToString();
                textBox5.Text = dataGridView1.Rows[Convert.ToUInt16(textBox1.Text) - 1].Cells[3].Value.ToString();
                textBox6.Text = dataGridView1.Rows[Convert.ToUInt16(textBox1.Text) - 1].Cells[4].Value.ToString();
                textBox7.Text = dataGridView1.Rows[Convert.ToUInt16(textBox1.Text) - 1].Cells[5].Value.ToString();
                textBox8.Text = dataGridView1.Rows[Convert.ToUInt16(textBox1.Text) - 1].Cells[6].Value.ToString();
                textBox9.Text = dataGridView1.Rows[Convert.ToUInt16(textBox1.Text) - 1].Cells[7].Value.ToString();
                textBox10.Text = dataGridView1.Rows[Convert.ToUInt16(textBox1.Text) - 1].Cells[8].Value.ToString();
                textBox11.Text = dataGridView1.Rows[Convert.ToUInt16(textBox1.Text) - 1].Cells[9].Value.ToString();
                textBox12.Text = dataGridView1.Rows[Convert.ToUInt16(textBox1.Text) - 1].Cells[10].Value.ToString();
                textBox13.Text = dataGridView1.Rows[Convert.ToUInt16(textBox1.Text) - 1].Cells[11].Value.ToString();
                textBox14.Text = dataGridView1.Rows[Convert.ToUInt16(textBox1.Text) - 1].Cells[12].Value.ToString();
                textBox15.Text = dataGridView1.Rows[Convert.ToUInt16(textBox1.Text) - 1].Cells[13].Value.ToString();
                textBox16.Text = dataGridView1.Rows[Convert.ToUInt16(textBox1.Text) - 1].Cells[14].Value.ToString();
                textBox17.Text = dataGridView1.Rows[Convert.ToUInt16(textBox1.Text) - 1].Cells[15].Value.ToString();
            }

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            Byte ID = 0,Sum = 0;
            Byte LPOS = 0, HPOS = 0;
            UInt16 pos = 0;
            Byte[] Power_off = { 0xff, 0xff, 0x00, 0x04, 0x03, 0x18, 0x00, 0x00 };
            Byte[] SET_POS = { 0xff, 0xff, 0x00, 0x05, 0x03, 0x1E, 0x00, 0x00, 0x00 };
            if (checkBox1.Checked == false)
            {
                textBox1.Text = "1";
                for(byte i=0;i<16;i++)
                {
                    ID = i;
                    Sum = 0;
                    Power_off[2] = ID;
                    for(UInt16 j=2;j<Power_off.Length-1;j++)
                    {
                        Sum += Power_off[j];
                    }
                    Sum = (byte)~Sum;
                    Power_off[Power_off.Length - 1] = Sum;
                    Port_Send(Power_off, Power_off.Length);
                }
                
             }
            else
            {
                textBox1.Text = "1";
                for (byte i = 0; i < 16; i++)
                {
                    ID = i;
                    Sum = 0;
                    pos = Convert.ToUInt16(dataGridView1.Rows[0].Cells[i].Value);
                    LPOS = (byte)pos;
                    HPOS = (byte)((pos&0xff00)/256);
                    SET_POS[2] = ID;
                    SET_POS[6] = LPOS;
                    SET_POS[7] = HPOS;
                    for (UInt16 j = 2; j < SET_POS.Length - 1; j++)
                    {
                        Sum += SET_POS[j];
                    }
                    Sum = (byte)~Sum;
                    SET_POS[SET_POS.Length - 1] = Sum;
                    Port_Send(SET_POS, SET_POS.Length);
                }
            }
        }
        private void Port_Send(byte[] data, int count)
        {
            try
            {

                serialPort1.Write(data, 0, count);

            }
            catch
            {
                MessageBox.Show("串口未打开或异常");
            }
        }

        private void button4_Click(object sender, EventArgs e)//上一帧
        {
            if(checkBox1.Checked == true)
            {
                UInt32 currunt_count = 0;
                Byte ID = 0, Sum = 0;
                Byte LPOS = 0, HPOS = 0;
                UInt16 pos = 0;
                Byte[] SET_POS = { 0xff, 0xff, 0x00, 0x05, 0x03, 0x1E, 0x00, 0x00, 0x00 };
                if (Convert.ToUInt32(textBox1.Text) <= 1)
                {
                    textBox1.Text = "1";
                }
                else
                {
                    currunt_count = Convert.ToUInt32(textBox1.Text);
                    currunt_count -= 1;
                    textBox1.Text = currunt_count.ToString();

                    for (byte i = 0; i < 16; i++)
                    {
                        ID = i;
                        Sum = 0;
                        pos = Convert.ToUInt16(dataGridView1.Rows[Convert.ToUInt16(textBox1.Text) - 1].Cells[i].Value);
                        LPOS = (byte)pos;
                        HPOS = (byte)((pos & 0xff00) / 256);
                        SET_POS[2] = ID;
                        SET_POS[6] = LPOS;
                        SET_POS[7] = HPOS;
                        for (UInt16 j = 2; j < SET_POS.Length - 1; j++)
                        {
                            Sum += SET_POS[j];
                        }
                        Sum = (byte)~Sum;
                        SET_POS[SET_POS.Length - 1] = Sum;
                        Port_Send(SET_POS, SET_POS.Length);
                    }
                }
            }

        }

        private void button5_Click(object sender, EventArgs e)//下一帧
        {
            if(checkBox1.Checked)
            {
                UInt32 currunt_count = 0;
                Byte ID = 0, Sum = 0;
                Byte LPOS = 0, HPOS = 0;
                UInt16 pos = 0;
                Byte[] SET_POS = { 0xff, 0xff, 0x00, 0x05, 0x03, 0x1E, 0x00, 0x00, 0x00 };
                if (Convert.ToUInt32(textBox1.Text) >= dataGridView1.RowCount - 1)
                {
                    textBox1.Text = (dataGridView1.RowCount - 1).ToString();
                }
                else
                {
                    currunt_count = Convert.ToUInt32(textBox1.Text);
                    currunt_count += 1;
                    textBox1.Text = currunt_count.ToString();
                    for (byte i = 0; i < 16; i++)
                    {
                        ID = i;
                        Sum = 0;
                        pos = Convert.ToUInt16(dataGridView1.Rows[Convert.ToUInt16(textBox1.Text) - 1].Cells[i].Value);
                        LPOS = (byte)pos;
                        HPOS = (byte)((pos & 0xff00) / 256);
                        SET_POS[2] = ID;
                        SET_POS[6] = LPOS;
                        SET_POS[7] = HPOS;
                        for (UInt16 j = 2; j < SET_POS.Length - 1; j++)
                        {
                            Sum += SET_POS[j];
                        }
                        Sum = (byte)~Sum;
                        SET_POS[SET_POS.Length - 1] = Sum;
                        Port_Send(SET_POS, SET_POS.Length);
                    }
                }
            }

        }
    }
}
